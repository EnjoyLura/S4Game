/** Shared square rarity sockets for equipment and materials; surrounding cards stay neutral. */
import { Color, Graphics, Node } from 'cc';
import { C, N } from './UIKit';
import { comicPlate } from './ComicUI';

export interface GearQualityStyle { name: string; edge: string; text: string; well: string; light: string; }
const STYLES: readonly GearQualityStyle[] = [
  { name: '普通', edge: '#85949C', text: '#455761', well: '#E9EDEB', light: '#D6DFDF' },
  { name: '优秀', edge: '#459C32', text: '#286A24', well: '#DCECC3', light: '#B1DF7B' },
  { name: '稀有', edge: '#278CD7', text: '#205E9C', well: '#D3EAF9', light: '#8CD6FF' },
  { name: '史诗', edge: '#A04DD1', text: '#7631A1', well: '#EBDDFA', light: '#D6A4F2' },
];
export function gearQuality(q: number): GearQualityStyle { return STYLES[q] || STYLES[0]; }

/** All equipment uses the same neutral paper face and ink contour. */
export function gearPlate(parent: Node, x: number, y: number, w: number, h: number, q: number,
  opts: { name?: string; cut?: number } = {}): Node {
  return comicPlate(parent, x, y, w, h, 'card', { name: opts.name || 'gearItemPlate', cut: opts.cut ?? 8 });
}

/** Legacy entry point shared by shop, inventory and loot; only the illustration's socket is colored. */
export function gearQualityHalo(parent: Node, x: number, y: number, w: number, h: number, q: number): void {
  const style = gearQuality(q), side = Math.min(w, h), half = side / 2;
  const g = N('gearQualitySquare', parent, x, y, side, side).addComponent(Graphics);
  const cut = Math.min(5, side * .055);
  const shape = (inset: number): void => {
    const a = half - inset, c = Math.max(1, cut - inset * .35);
    g.moveTo(-a+c,-a); g.lineTo(a-c,-a); g.lineTo(a,-a+c); g.lineTo(a,a-c);
    g.lineTo(a-c,a); g.lineTo(-a+c,a); g.lineTo(-a,a-c); g.lineTo(-a,-a+c); g.close();
  };
  g.fillColor = C('#26312D'); shape(0); g.fill();
  g.fillColor = C(style.edge); shape(1.5); g.fill();
  const deep = C(['#46535B','#173D1F','#163A59','#38204F'][q] || '#46535B');
  const rim = C(style.edge), inner = side - 8;
  for (let i = 0; i < 16; i++) {
    g.fillColor = Color.lerp(new Color(), deep, rim, .16 + i / 15 * .34);
    g.rect(-half+4, -half+4+i*inner/16, inner, inner/16+.25); g.fill();
  }
  g.strokeColor = C(style.light); g.lineWidth = Math.max(1, side * .012);
  g.moveTo(-half+6,half-3); g.lineTo(half-6,half-3); g.stroke();
  g.moveTo(-half+3,-half+6); g.lineTo(-half+3,half-6); g.stroke();
}
