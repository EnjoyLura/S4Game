/** Comic outpost gates: unchanged closing/opening movement with a 1.5-second closed-door beat. */
import { _decorator, BlockInputEvents, Camera, Canvas, Color, Component, director, Director,
  game, Game, isValid, Graphics, Node, Rect, Size, Sprite, SpriteFrame, UITransform, Vec2, view } from 'cc';
import { reducedMotion } from './UIMotion';
import { uxFrame } from './Ux';
import { ENTRY_GATE_ART, warmBattleScene } from './BattleEntryWarmup';
import { whenUIArtReady } from './UIArtReady';
import { GameAudio } from '../core/GameAudio';

const { ccclass } = _decorator;
const LAYER = 1 << 19;
const CLOSE_SECONDS = .24;
const OPEN_SECONDS = .32;
const CLOSED_HOLD_SECONDS = 1.5;
const ART_WAIT_LIMIT = .9;
type Destination = 'battle' | 'main';
type SceneLoader = (done: (error?: Error | null) => void) => boolean;
let active: BattleEntry | null = null;
let gateFrames: [SpriteFrame, SpriteFrame] | null = null;
const clamp = (v: number): number => Math.max(0, Math.min(1, v));
const ease = (v: number): number => { const p = clamp(v); return p * p * (3 - 2 * p); };

/** Both travel directions hold input and suppress the destination's ordinary root fade. */
export function enteringBattle(): boolean { return !!active && isValid(active.node, true); }

/** The persistent opaque surface owns input blocking; the button keeps its normal caption and skin. */
export function enterBattle(load: (done: (error?: Error | null) => void) => boolean,
  failed: () => void, firstPaint: Promise<void> = Promise.resolve()): void {
  startTransition('battle', load, failed, firstPaint);
}

/** Battle exits share the same art and timing; loading begins only behind fully closed gates. */
export function leaveBattle(load: SceneLoader, failed: () => void): void {
  startTransition('main', load, failed, Promise.resolve());
}

function startTransition(destination: Destination, load: SceneLoader,
  failed: () => void, firstPaint: Promise<void>): void {
  if (enteringBattle()) return;
  const scene = director.getScene(); if (!scene) { failed(); return; }
  const root = new Node('BattleEntrySurface'); root.layer = LAYER; root.setParent(scene);
  root.addComponent(UITransform).setContentSize(view.getVisibleSize());
  const canvas = root.addComponent(Canvas); canvas.alignCanvasWithScreen = true;
  const cameraNode = new Node('BattleEntryCamera'); cameraNode.layer = LAYER; cameraNode.setParent(root);
  cameraNode.setPosition(0, 0, 1000);
  const camera = cameraNode.addComponent(Camera);
  camera.projection = Camera.ProjectionType.ORTHO; camera.near = 0; camera.far = 2000;
  camera.visibility = LAYER; camera.priority = 100; camera.clearFlags = Camera.ClearFlag.DEPTH_ONLY;
  camera.orthoHeight = view.getVisibleSize().height / 2; canvas.cameraComponent = camera;
  root.addComponent(BlockInputEvents);
  director.addPersistRootNode(root);
  const transition = root.addComponent(BattleEntry); active = transition;
  transition.configure(camera, load, failed, firstPaint, destination);
}

/** BattleDirector has constructed its full tree; its first complete draw must precede the reveal. */
export function battleEntryReady(root: Node): void { active?.waitForDestination('battle', root); }

/** Includes the level page's nested artwork/refresh handoffs before revealing the lobby. */
export function levelReturnReady(root: Node): void { active?.waitForDestination('main', root); }

@ccclass('BattleEntry')
export class BattleEntry extends Component {
  private left!: Node;
  private right!: Node;
  private leftInk!: Graphics;
  private rightInk!: Graphics;
  private leftArt!: Sprite;
  private rightArt!: Sprite;
  private camera!: Camera;
  private phase: 'closing' | 'holding' | 'opening' = 'closing';
  private destination: Destination = 'battle';
  private age = 0;
  private lastFrameAt = 0;
  private builtAge = 0;
  private coverage = 0;
  private openingFrom = 1;
  private width = 0;
  private height = 0;
  private quiet = false;
  private hidden = false;
  private preloaded = false;
  private loadStarted = false;
  private builtRoot: Node | null = null;
  private ready = false;
  private failed = false;
  private firstPaint!: Promise<void>;
  private load!: (done: (error?: Error | null) => void) => boolean;
  private fail!: () => void;
  private drawReady: (() => void) | null = null;

  onLoad(): void {
    game.on(Game.EVENT_HIDE, this.hide, this); game.on(Game.EVENT_SHOW, this.show, this);
  }
  configure(camera: Camera, load: (done: (error?: Error | null) => void) => boolean,
    failed: () => void, firstPaint: Promise<void>, destination: Destination): void {
    this.camera = camera; this.load = load; this.fail = failed;
    this.destination = destination;
    if (destination === 'battle') GameAudio.holdMusicForTransition(true);
    this.lastFrameAt = performance.now();
    this.firstPaint = firstPaint; this.quiet = reducedMotion();
    const panel = (name: string): Graphics => {
      const n = new Node(name); n.layer = LAYER; n.setParent(this.node); return n.addComponent(Graphics);
    };
    this.leftInk = panel('leftOutpostGate'); this.left = this.leftInk.node;
    this.rightInk = panel('rightOutpostGate'); this.right = this.rightInk.node;
    this.leftArt = this.makeArt(this.left, 1); this.rightArt = this.makeArt(this.right, 0);
    this.resize(); this.draw(0);
    GameAudio.play('gateSlide');
    uxFrame(ENTRY_GATE_ART, source => {
      if (!source || !isValid(this.node, true) || this.phase === 'opening') return;
      if (!gateFrames) {
        source.packable = false; source.texture.addRef();
        const r = source.rect, half = r.width / 2;
        const frames = [0, 1].map(side => {
          const frame = new SpriteFrame();
          frame.reset({ texture: source.texture, rect: new Rect(r.x + half * side, r.y, half, r.height),
            originalSize: new Size(half, r.height), offset: new Vec2() });
          frame.packable = false;
          return frame;
        });
        gateFrames = [frames[0], frames[1]];
      }
      this.leftArt.spriteFrame = gateFrames[0]; this.rightArt.spriteFrame = gateFrames[1];
      this.fitArt();
    });
    void warmBattleScene().then(ok => {
      if (!isValid(this.node, true) || this.failed) return;
      if (ok) this.preloaded = true; else this.abort();
    });
  }
  private makeArt(parent: Node, anchorX: number): Sprite {
    const n = new Node('paintedGateHalf'); n.layer = LAYER; n.setParent(parent);
    n.addComponent(UITransform).setAnchorPoint(anchorX, .5);
    const sprite = n.addComponent(Sprite); sprite.sizeMode = Sprite.SizeMode.CUSTOM; sprite.trim = false;
    return sprite;
  }
  private fitArt(): void {
    if (!gateFrames) return;
    const r = gateFrames[0].rect;
    const scale = Math.max((this.width + 4) / (r.width * 2), (this.height + 4) / r.height);
    for (const sprite of [this.leftArt, this.rightArt]) {
      sprite.node.getComponent(UITransform)!.setContentSize(r.width * scale, r.height * scale);
    }
  }
  waitForDestination(destination: Destination, root: Node): void {
    if (destination !== this.destination || !this.loadStarted || this.failed) return;
    this.builtRoot = root; this.builtAge = 0;
    if (destination === 'main') {
      whenUIArtReady(root, () => this.queueFirstDraw());
    } else {
      // Decorative HUD images load independently. Only the background, wall and actual idle clips matter here.
      void this.firstPaint.then(() => this.queueFirstDraw());
    }
  }
  private queueFirstDraw(): void {
    if (!isValid(this.node, true) || !isValid(this.builtRoot, true) || this.failed || this.ready || this.drawReady) return;
    this.drawReady = () => {
      this.drawReady = null;
      if (isValid(this.node, true) && isValid(this.builtRoot, true)) this.ready = true;
    };
    director.once(Director.EVENT_AFTER_DRAW, this.drawReady);
  }
  update(dt: number): void {
    if (this.hidden || !this.left) return;
    const now = performance.now(), elapsed = Math.max(0, (now - this.lastFrameAt) / 1000);
    this.lastFrameAt = now;
    const delta = Math.min(Math.max(dt, 0), .1);
    this.resize();
    // Scene construction can block a frame: those visible closed-door milliseconds count too.
    this.age += this.phase === 'holding' ? elapsed : delta;
    if (this.builtRoot && !this.ready) {
      this.builtAge += elapsed;
      // A stalled network must not add the former eight-second closed-door wait.
      if (this.destination === 'battle' && this.builtAge >= ART_WAIT_LIMIT) this.queueFirstDraw();
    }
    if (this.phase === 'closing') {
      const p = clamp(this.age / (this.quiet ? .08 : CLOSE_SECONDS));
      this.draw(1 - Math.pow(1 - p, 3));
      if (p >= 1) {
        this.phase = 'holding'; this.age = 0;
        // Follow actual visual closure, including reduced motion; never use a delayed timer.
        GameAudio.play('gateClose');
      }
    } else if (this.phase === 'holding') {
      this.draw(1);
      if (this.preloaded && !this.loadStarted && !this.failed) {
        this.loadStarted = true;
        const started = this.load(error => { if (error && isValid(this.node, true)) this.abort(); });
        if (!started) this.abort();
      }
      if (!this.loadStarted && this.age >= 5) this.abort();
      if (!this.failed && this.age >= CLOSED_HOLD_SECONDS && this.ready) {
        this.phase = 'opening'; this.age = 0;
      }
    } else {
      const p = this.age / (this.quiet ? .1 : OPEN_SECONDS);
      this.draw(this.openingFrom * (1 - ease(p)));
      if (p >= 1) this.finish();
    }
  }
  private resize(): void {
    const size = view.getVisibleSize();
    if (this.width === size.width && this.height === size.height) return;
    this.width = size.width; this.height = size.height;
    this.node.getComponent(UITransform)!.setContentSize(size);
    this.camera.orthoHeight = size.height / 2;
    this.paintBacking(this.leftInk, -1); this.paintBacking(this.rightInk, 1);
    this.fitArt();
  }
  private paintBacking(g: Graphics, side: number): void {
    const w = this.width / 2 + 128, h = this.height / 2 + 8;
    g.clear(); g.fillColor = new Color(137, 87, 45, 255);
    g.rect(side < 0 ? -w : -1, -h, w + 1, h * 2); g.fill();
    // Solid backup remains behind the painted resource; never reveal a one-pixel edge or clear frame.
    g.strokeColor = new Color(57, 40, 29, 255); g.lineWidth = 3;
    g.moveTo(side * 4, -h); g.lineTo(side * 4, h); g.stroke();
  }
  private draw(coverage: number): void {
    this.coverage = coverage;
    const slide = (1 - coverage) * (this.width / 2 + 8);
    this.left.setPosition(-slide, 0, 0); this.right.setPosition(slide, 0, 0);
  }
  private abort(): void {
    if (this.failed) return;
    this.failed = true; this.fail(); this.openingFrom = this.coverage; this.phase = 'opening'; this.age = 0;
  }
  private finish(): void {
    if (active === this) active = null;
    if (this.destination === 'battle') GameAudio.holdMusicForTransition(false);
    director.removePersistRootNode(this.node); this.node.active = false; this.node.destroy();
  }
  private hide = (): void => { this.hidden = true; };
  private show = (): void => { this.lastFrameAt = performance.now(); this.hidden = false; };
  onDestroy(): void {
    if (this.destination === 'battle') GameAudio.holdMusicForTransition(false);
    game.off(Game.EVENT_HIDE, this.hide, this); game.off(Game.EVENT_SHOW, this.show, this);
    if (this.drawReady) director.off(Director.EVENT_AFTER_DRAW, this.drawReady);
    if (active === this) active = null;
  }
}
